import React from 'react';
import "./styles.css";
const Header = () =>(
    <header id="main-header">Noticias</header>
);
export default Header;